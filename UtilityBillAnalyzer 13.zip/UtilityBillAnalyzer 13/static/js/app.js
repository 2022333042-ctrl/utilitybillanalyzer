// Small global UI enhancements.
// The main charts and converter are initialized by their individual templates.
document.querySelectorAll(".flash").forEach((el) => {
    setTimeout(() => {
        el.style.transition = "opacity .4s ease";
        el.style.opacity = "0";
    }, 4500);
});
