from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import sqlite3
from datetime import datetime
from urllib.request import urlopen, Request
import json
import csv
import io
from statistics import mean
from flask import make_response

app = Flask(__name__)
app.secret_key = "utility-analyzer-local-secret"
DB_PATH = "utility.db"

CURRENCIES = {
    "BDT": "Bangladeshi Taka",
    "USD": "US Dollar",
    "EUR": "Euro",
    "GBP": "British Pound",
    "CAD": "Canadian Dollar",
    "AUD": "Australian Dollar",
    "JPY": "Japanese Yen",
    "CNY": "Chinese Yuan",
    "INR": "Indian Rupee",
    "SGD": "Singapore Dollar",
    "AED": "UAE Dirham",
    "SAR": "Saudi Riyal",
    "MYR": "Malaysian Ringgit",
    "KRW": "South Korean Won",
    "CHF": "Swiss Franc",
    "NZD": "New Zealand Dollar",
    "THB": "Thai Baht",
    "NOK": "Norwegian Krone",
    "SEK": "Swedish Krona",
    "DKK": "Danish Krone",
}

UTILITY_TYPES = ["Electricity", "Gas", "Water", "Internet", "Mobile", "Other"]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS bills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            utility_type TEXT NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL,
            billing_month TEXT NOT NULL,
            note TEXT DEFAULT '',
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def money(value, currency="BDT"):
    symbols = {
        "BDT": "৳", "USD": "$", "EUR": "€", "GBP": "£",
        "CAD": "C$", "AUD": "A$", "JPY": "¥", "CNY": "¥",
        "INR": "₹", "SGD": "S$", "AED": "د.إ", "SAR": "﷼",
        "MYR": "RM", "KRW": "₩", "CHF": "CHF", "NZD": "NZ$",
        "THB": "฿", "NOK": "kr", "SEK": "kr", "DKK": "kr"
    }
    return f"{symbols.get(currency, currency + ' ')}{value:,.2f}"


def get_bills():
    conn = get_db()
    bills = conn.execute(
        "SELECT * FROM bills ORDER BY billing_month DESC, id DESC"
    ).fetchall()
    conn.close()
    return bills


def build_insights(bills):
    if not bills:
        return [{
            "type": "info",
            "title": "Start tracking",
            "text": "Add your first utility bill to unlock spending analysis and recommendations."
        }]

    # Analysis is performed per original currency. Dashboard totals are converted
    # to the selected display currency before aggregation.
    return []



def monthly_analysis(bills, display_currency="BDT"):
    """Aggregate bills by month in a display currency, tolerating rate API outages."""
    month_totals = {}
    utility_totals = {}
    conversion_errors = set()
    for bill in bills:
        original = float(bill["amount"])
        try:
            amount = convert_amount(original, bill["currency"], display_currency)
        except Exception:
            amount = original if bill["currency"] == display_currency else 0.0
            if bill["currency"] != display_currency:
                conversion_errors.add(bill["currency"])
        month = bill["billing_month"]
        utility = bill["utility_type"]
        month_totals[month] = month_totals.get(month, 0.0) + amount
        utility_totals[utility] = utility_totals.get(utility, 0.0) + amount
    months = sorted(month_totals)
    return month_totals, utility_totals, months, sorted(conversion_errors)


def build_smart_insights(month_totals, utility_totals, months):
    insights = []
    if len(months) >= 2:
        latest, previous = month_totals[months[-1]], month_totals[months[-2]]
        if previous > 0:
            change = (latest - previous) / previous * 100
            if change >= 15:
                insights.append(("warning", "Spending jumped", f"Your latest recorded month is {change:.1f}% higher than the previous month. Check for unusually high usage or one-off charges."))
            elif change <= -10:
                insights.append(("success", "Spending moved down", f"Your latest recorded month is {abs(change):.1f}% lower than the previous month. Compare usage to see what helped."))
            else:
                insights.append(("info", "Spending is relatively steady", f"Your latest month changed by {change:+.1f}% from the previous month."))
    if utility_totals:
        top = max(utility_totals, key=utility_totals.get)
        total = sum(utility_totals.values())
        share = utility_totals[top] / total * 100 if total else 0
        insights.append(("tip", f"Review {top}", f"{top} accounts for {share:.1f}% of tracked spending in the selected currency. It may be the best place to investigate savings."))
    if not insights:
        insights.append(("info", "Build your baseline", "Add bills for at least two different months to unlock meaningful trend comparisons."))
    if "Electricity" in utility_totals:
        insights.append(("tip", "Energy-saving checklist", "Try switching off idle devices, using efficient lighting, and comparing electricity bills across similar months. Cost alone cannot determine kWh or carbon emissions, so this app does not invent an emissions estimate."))
    if "Water" in utility_totals:
        insights.append(("tip", "Water-saving checklist", "Check for leaks, avoid leaving taps running, and compare water bills across similar billing periods."))
    return insights


def fetch_rate(from_currency, to_currency):
    if from_currency == to_currency:
        return 1.0

    # Public endpoint. If it is unavailable, the UI will report the issue.
    url = f"https://open.er-api.com/v6/latest/{from_currency}"
    req = Request(url, headers={"User-Agent": "UtilityBillAnalyzer/1.0"})
    with urlopen(req, timeout=8) as response:
        data = json.loads(response.read().decode("utf-8"))
    if data.get("result") != "success":
        raise RuntimeError("Exchange-rate service returned an error.")
    rate = data.get("rates", {}).get(to_currency)
    if rate is None:
        raise RuntimeError("Currency is not supported by the exchange-rate service.")
    return float(rate)


def convert_amount(amount, from_currency, to_currency):
    return amount * fetch_rate(from_currency, to_currency)


@app.context_processor
def inject_globals():
    return {
        "currencies": CURRENCIES,
        "utility_types": UTILITY_TYPES,
        "money": money
    }


@app.route("/")
def dashboard():
    bills = get_bills()
    display_currency = request.args.get("currency", "BDT").upper()
    if display_currency not in CURRENCIES:
        display_currency = "BDT"

    converted = []
    conversion_errors = []

    for bill in bills:
        try:
            converted_amount = convert_amount(
                float(bill["amount"]), bill["currency"], display_currency
            )
        except Exception:
            converted_amount = float(bill["amount"]) if bill["currency"] == display_currency else 0
            if bill["currency"] != display_currency:
                conversion_errors.append(bill["currency"])
        converted.append({
            "id": bill["id"],
            "utility_type": bill["utility_type"],
            "amount": converted_amount,
            "billing_month": bill["billing_month"],
        })

    total = sum(x["amount"] for x in converted)
    utility_totals = {}
    month_totals = {}

    for item in converted:
        utility_totals[item["utility_type"]] = utility_totals.get(item["utility_type"], 0) + item["amount"]
        month_totals[item["billing_month"]] = month_totals.get(item["billing_month"], 0) + item["amount"]

    months = sorted(month_totals.keys())
    latest_month = months[-1] if months else None
    previous_month = months[-2] if len(months) >= 2 else None

    current_total = month_totals.get(latest_month, 0) if latest_month else 0
    previous_total = month_totals.get(previous_month, 0) if previous_month else 0

    change_pct = None
    if previous_total:
        change_pct = ((current_total - previous_total) / previous_total) * 100

    highest_utility = max(utility_totals, key=utility_totals.get) if utility_totals else "—"

    insights = []
    if latest_month:
        if change_pct is not None:
            if change_pct > 15:
                insights.append(("warning", "Spending increased", f"Your latest month is {change_pct:.1f}% higher than the previous month."))
            elif change_pct < -10:
                insights.append(("success", "Good progress", f"Your latest month is {abs(change_pct):.1f}% lower than the previous month."))
            else:
                insights.append(("info", "Spending is stable", "Your latest month's total is relatively close to the previous month."))
        if highest_utility != "—":
            insights.append(("tip", "Largest expense", f"{highest_utility} is currently your largest utility category. Review its usage first when looking for savings."))

    if not insights:
        insights.append(("info", "Start tracking", "Add more bills across several months to unlock stronger comparisons."))

    chart_months = months[-12:]
    line_values = [month_totals[m] for m in chart_months]

    return render_template(
        "dashboard.html",
        active="dashboard",
        bills=bills[:8],
        display_currency=display_currency,
        total=total,
        current_total=current_total,
        previous_total=previous_total,
        change_pct=change_pct,
        highest_utility=highest_utility,
        utility_labels=list(utility_totals.keys()),
        utility_values=list(utility_totals.values()),
        chart_months=chart_months,
        line_values=line_values,
        insights=insights,
        conversion_errors=sorted(set(conversion_errors)),
    )


@app.route("/add", methods=["GET", "POST"])
def add_bill():
    if request.method == "POST":
        utility_type = request.form.get("utility_type", "").strip()
        amount_text = request.form.get("amount", "").strip()
        currency = request.form.get("currency", "BDT").upper()
        billing_month = request.form.get("billing_month", "").strip()
        note = request.form.get("note", "").strip()

        try:
            amount = float(amount_text)
            if amount <= 0:
                raise ValueError
        except ValueError:
            flash("Enter a valid amount greater than zero.", "error")
            return render_template("add_bill.html", active="add")

        if utility_type not in UTILITY_TYPES:
            flash("Choose a valid utility type.", "error")
            return render_template("add_bill.html", active="add")

        if currency not in CURRENCIES:
            flash("Choose a valid currency.", "error")
            return render_template("add_bill.html", active="add")

        if not billing_month:
            billing_month = datetime.now().strftime("%Y-%m")

        conn = get_db()
        conn.execute("""
            INSERT INTO bills (utility_type, amount, currency, billing_month, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (utility_type, amount, currency, billing_month, note, datetime.now().isoformat()))
        conn.commit()
        conn.close()

        flash("Bill added successfully.", "success")
        return redirect(url_for("dashboard"))

    return render_template("add_bill.html", active="add")


@app.route("/history")
def history():
    bills = get_bills()
    return render_template("history.html", active="history", bills=bills)


@app.post("/delete/<int:bill_id>")
def delete_bill(bill_id):
    conn = get_db()
    conn.execute("DELETE FROM bills WHERE id = ?", (bill_id,))
    conn.commit()
    conn.close()
    flash("Bill deleted.", "success")
    return redirect(request.referrer or url_for("history"))


@app.route("/analytics")
def analytics():
    bills = get_bills()
    display_currency = request.args.get("currency", "BDT").upper()
    if display_currency not in CURRENCIES:
        display_currency = "BDT"

    month_totals = {}
    utility_totals = {}

    for bill in bills:
        try:
            amount = convert_amount(float(bill["amount"]), bill["currency"], display_currency)
        except Exception:
            amount = float(bill["amount"]) if bill["currency"] == display_currency else 0

        month = bill["billing_month"]
        month_totals[month] = month_totals.get(month, 0) + amount
        utility = bill["utility_type"]
        utility_totals[utility] = utility_totals.get(utility, 0) + amount

    months = sorted(month_totals.keys())
    return render_template(
        "analytics.html",
        active="analytics",
        display_currency=display_currency,
        chart_months=months,
        line_values=[month_totals[m] for m in months],
        utility_labels=list(utility_totals.keys()),
        utility_values=list(utility_totals.values()),
    )


@app.route("/insights")
def smart_insights():
    bills = get_bills()
    display_currency = request.args.get("currency", "BDT").upper()
    if display_currency not in CURRENCIES:
        display_currency = "BDT"
    month_totals, utility_totals, months, conversion_errors = monthly_analysis(bills, display_currency)
    recent_months = months[-12:]
    recent_values = [month_totals[m] for m in recent_months]
    # Simple, explainable baseline: average of up to the latest three recorded months.
    forecast = mean(recent_values[-3:]) if recent_values else 0.0
    latest_total = recent_values[-1] if recent_values else 0.0
    forecast_label = "Estimated next-month spend" if len(recent_values) >= 2 else "Early estimate (limited data)"
    insights = build_smart_insights(month_totals, utility_totals, months)
    return render_template(
        "insights.html", active="insights", display_currency=display_currency,
        months=recent_months, month_values=recent_values, forecast=forecast,
        forecast_label=forecast_label, latest_total=latest_total,
        utility_labels=list(utility_totals.keys()), utility_values=list(utility_totals.values()),
        insights=insights, conversion_errors=conversion_errors, bill_count=len(bills),
    )


@app.get("/export.csv")
def export_csv():
    bills = get_bills()
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["ID", "Utility type", "Amount", "Currency", "Billing month", "Note", "Created at"])
    for bill in bills:
        writer.writerow([bill["id"], bill["utility_type"], bill["amount"], bill["currency"], bill["billing_month"], bill["note"], bill["created_at"]])
    response = make_response("\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = "attachment; filename=utilitywise-bills.csv"
    return response


@app.route("/converter")
def converter():
    return render_template("converter.html", active="converter")


@app.get("/api/convert")
def api_convert():
    try:
        amount = float(request.args.get("amount", "0"))
        from_currency = request.args.get("from", "BDT").upper()
        to_currency = request.args.get("to", "USD").upper()

        if amount < 0:
            raise ValueError

        result = convert_amount(amount, from_currency, to_currency)
        rate = fetch_rate(from_currency, to_currency)

        return jsonify({
            "success": True,
            "amount": amount,
            "from": from_currency,
            "to": to_currency,
            "rate": rate,
            "result": result
        })
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 400


@app.route("/assistant")
def assistant():
    return render_template("assistant.html", active="assistant")


@app.post("/api/chat")
def api_chat():
    """Send a user message and a compact bill summary to the local Ollama model."""
    payload = request.get_json(silent=True) or {}
    message = str(payload.get("message", "")).strip()
    if not message:
        return jsonify({"success": False, "error": "Please type a message first."}), 400
    if len(message) > 4000:
        return jsonify({"success": False, "error": "Message is too long. Please keep it under 4,000 characters."}), 400

    # Give the model real app data so it can answer questions about recorded bills.
    bills = get_bills()
    bill_context = [
        {
            "utility_type": bill["utility_type"],
            "amount": float(bill["amount"]),
            "currency": bill["currency"],
            "billing_month": bill["billing_month"],
        }
        for bill in bills[:100]
    ]
    system_prompt = (
        "You are UtilityWise Assistant, a practical utility-bill analysis helper. "
        "Help users understand electricity, gas, water, internet, and other household utility spending. "
        "Use the bill records supplied in the conversation when answering questions about their data. "
        "The records may use different currencies; do not add amounts in different currencies together. "
        "Never invent bill records, exchange rates, or savings figures. If the data is insufficient, say so. "
        "Offer clear, concise, actionable suggestions. You are not a financial adviser."
    )
    user_prompt = (
        f"Recorded utility bills (JSON, newest first; up to 100 records):\n"
        f"{json.dumps(bill_context, ensure_ascii=False)}\n\n"
        f"User question: {message}"
    )
    request_body = json.dumps({
        "model": "qwen2.5:3b",
        "stream": False,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "options": {"temperature": 0.3},
    }).encode("utf-8")
    req = Request(
        "http://127.0.0.1:11434/api/chat",
        data=request_body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(req, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))
        answer = result.get("message", {}).get("content", "").strip()
        if not answer:
            raise RuntimeError("Ollama returned an empty response.")
        return jsonify({"success": True, "reply": answer})
    except Exception as exc:
        return jsonify({
            "success": False,
            "error": (
                "Could not reach the local Ollama model. Make sure Ollama is running "
                "and that `ollama list` shows `qwen2.5:3b`. Details: " + str(exc)
            ),
        }), 503


@app.route("/settings")
def settings():
    return render_template("settings.html", active="settings")


init_db()

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
